"""
NoteVault - REMEDIATED version.
This file demonstrates the fix for every finding raised in the security
code review (see SECURITY_AUDIT_REPORT.docx). Comments reference the
finding ID that each change addresses.
"""

import os
import secrets
import sqlite3
from functools import wraps

from flask import Flask, request, render_template_string, jsonify, session, abort
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# --- Fix F-01: secret loaded from environment, never hardcoded --------------
app.secret_key = os.environ.get("NOTEVAULT_SECRET_KEY") or secrets.token_hex(32)

# --- Fix F-11: debug/host driven by environment, safe defaults -------------
DEBUG = os.environ.get("FLASK_DEBUG", "false").lower() == "true"
BIND_HOST = os.environ.get("BIND_HOST", "127.0.0.1")

DB_PATH = os.environ.get("NOTEVAULT_DB", "notevault.db")
EXPORT_DIR = os.path.abspath(os.environ.get("EXPORT_DIR", "./exports"))


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute(
        "CREATE TABLE IF NOT EXISTS users "
        "(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, is_admin INTEGER DEFAULT 0)"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS notes "
        "(id INTEGER PRIMARY KEY, user_id INTEGER, title TEXT, body TEXT)"
    )
    conn.commit()
    conn.close()


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        # --- Fix F-04/F-10: server-side session, not client-readable cookies
        if "user_id" not in session:
            abort(401)
        return f(*args, **kwargs)

    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            abort(403)
        return f(*args, **kwargs)

    return wrapper


@app.route("/register", methods=["POST"])
def register():
    username = request.form["username"].strip()
    password = request.form["password"]

    if len(password) < 12:
        return jsonify(error="password must be at least 12 characters"), 400

    # --- Fix F-02: salted, adaptive hashing (PBKDF2/Werkzeug) --------------
    password_hash = generate_password_hash(password)

    conn = get_db()
    try:
        # --- Fix F-03: parameterized query, no string interpolation -------
        conn.execute(
            "INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, 0)",
            (username, password_hash),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        return jsonify(error="username already taken"), 409
    finally:
        conn.close()
    return jsonify(status="registered"), 201


@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"].strip()
    password = request.form["password"]

    conn = get_db()
    # --- Fix F-03: parameterized query --------------------------------
    row = conn.execute(
        "SELECT id, password_hash, is_admin FROM users WHERE username = ?",
        (username,),
    ).fetchone()
    conn.close()

    # --- Fix F-02: verify with constant-time, salted check -------------
    if row and check_password_hash(row["password_hash"], password):
        # --- Fix F-04: identity kept server-side in the signed session --
        session.clear()
        session["user_id"] = row["id"]
        session["is_admin"] = bool(row["is_admin"])
        return jsonify(status="logged in")

    return jsonify(error="invalid credentials"), 401


@app.route("/notes/<int:note_id>")
@login_required
def get_note(note_id):
    conn = get_db()
    # --- Fix F-05: enforce ownership (or admin) before returning data ----
    row = conn.execute(
        "SELECT title, body, user_id FROM notes WHERE id = ?", (note_id,)
    ).fetchone()
    conn.close()

    if not row:
        abort(404)
    if row["user_id"] != session["user_id"] and not session.get("is_admin"):
        abort(403)

    # --- Fix F-06: Jinja auto-escapes {{ }} by default; no manual HTML ---
    template = "<h1>{{ title }}</h1><p>{{ body }}</p>"
    return render_template_string(template, title=row["title"], body=row["body"])


@app.route("/search")
@login_required
def search_notes():
    term = request.args.get("q", "")
    conn = get_db()
    # --- Fix F-03: parameterized LIKE query ------------------------------
    rows = conn.execute(
        "SELECT id, title FROM notes WHERE user_id = ? AND title LIKE ?",
        (session["user_id"], f"%{term}%"),
    ).fetchall()
    conn.close()
    return jsonify(results=[{"id": r["id"], "title": r["title"]} for r in rows])


@app.route("/export")
@login_required
def export_notes():
    filename = request.args.get("file", "notes.txt")

    # --- Fix F-07: reject path separators / traversal, confine to EXPORT_DIR
    safe_name = os.path.basename(filename)
    full_path = os.path.normpath(os.path.join(EXPORT_DIR, safe_name))
    if not full_path.startswith(EXPORT_DIR + os.sep):
        abort(400)
    if not os.path.isfile(full_path):
        abort(404)

    with open(full_path, "r") as f:
        data = f.read()
    return data, 200, {"Content-Type": "text/plain"}


ALLOWED_FORMATS = {"pdf", "html", "docx"}


@app.route("/convert", methods=["POST"])
@login_required
def convert_note():
    note_id = request.form["note_id"]
    target_format = request.form.get("format", "pdf")

    # --- Fix F-08: validate inputs, never build a shell string ------------
    if not note_id.isdigit():
        abort(400)
    if target_format not in ALLOWED_FORMATS:
        abort(400)

    src = os.path.join(EXPORT_DIR, f"note_{note_id}.md")
    dst = os.path.join(EXPORT_DIR, f"note_{note_id}.{target_format}")
    if not os.path.isfile(src):
        abort(404)

    # No shell=True, arguments passed as a list -> no shell metacharacter risk.
    # Resolve to an absolute path so we never rely on $PATH lookup at runtime.
    import shutil
    import subprocess

    pandoc_bin = shutil.which("pandoc") or "/usr/bin/pandoc"
    subprocess.run([pandoc_bin, src, "-o", dst], shell=False, check=True, timeout=30)  # nosec B603
    return jsonify(status="converted")


@app.route("/import", methods=["POST"])
@login_required
def import_notes():
    # --- Fix F-09: accept a safe, schema-validated format (JSON), never
    # pickle.loads on untrusted bytes.
    payload = request.get_json(force=True, silent=True)
    if not isinstance(payload, list):
        return jsonify(error="expected a JSON array of notes"), 400
    for item in payload:
        if not isinstance(item, dict) or "title" not in item or "body" not in item:
            return jsonify(error="each note needs 'title' and 'body'"), 400
    return jsonify(imported=len(payload))


@app.route("/admin/users")
@login_required
@admin_required
def list_users():
    # --- Fix F-10: now behind login_required + admin_required -------------
    conn = get_db()
    rows = conn.execute("SELECT id, username, is_admin FROM users").fetchall()
    conn.close()
    return jsonify(users=[dict(r) for r in rows])


if __name__ == "__main__":
    os.makedirs(EXPORT_DIR, exist_ok=True)
    init_db()
    # --- Fix F-11: safe local default; debug/host only opened via env vars
    app.run(host=BIND_HOST, port=5000, debug=DEBUG)
