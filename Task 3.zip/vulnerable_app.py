"""
NoteVault - a small internal notes/user-management web app.
This is the ORIGINAL, PRE-AUDIT version of the application and is used
as the subject of the security code review. Do not deploy as-is.
"""

import hashlib
import os
import pickle
import sqlite3
import subprocess

from flask import Flask, request, render_template_string, make_response, redirect

app = Flask(__name__)

# --- Finding: F-01 Hardcoded secret key -------------------------------------
app.secret_key = "dev-secret-12345"

DB_PATH = "notevault.db"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    return conn


def init_db():
    conn = get_db()
    conn.execute(
        "CREATE TABLE IF NOT EXISTS users "
        "(id INTEGER PRIMARY KEY, username TEXT, password TEXT, is_admin INTEGER)"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS notes "
        "(id INTEGER PRIMARY KEY, user_id INTEGER, title TEXT, body TEXT)"
    )
    conn.commit()
    conn.close()


# --- Finding: F-02 Weak password hashing (unsalted MD5) ---------------------
def hash_password(password: str) -> str:
    return hashlib.md5(password.encode()).hexdigest()


@app.route("/register", methods=["POST"])
def register():
    username = request.form["username"]
    password = request.form["password"]
    hashed = hash_password(password)

    conn = get_db()
    # --- Finding: F-03 SQL Injection (string-formatted query) ---------------
    query = "INSERT INTO users (username, password, is_admin) VALUES ('%s', '%s', 0)" % (
        username,
        hashed,
    )
    conn.execute(query)
    conn.commit()
    conn.close()
    return "registered"


@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    password = request.form["password"]
    hashed = hash_password(password)

    conn = get_db()
    # --- Finding: F-03 SQL Injection (string-formatted query) ---------------
    query = "SELECT id, is_admin FROM users WHERE username = '%s' AND password = '%s'" % (
        username,
        hashed,
    )
    cur = conn.execute(query)
    row = cur.fetchone()
    conn.close()

    if row:
        resp = make_response(redirect("/dashboard"))
        # --- Finding: F-04 Sensitive data in plaintext cookie, no flags -----
        resp.set_cookie("user_id", str(row[0]))
        resp.set_cookie("is_admin", str(row[1]))
        return resp
    return "invalid credentials", 401


@app.route("/notes/<int:note_id>")
def get_note(note_id):
    conn = get_db()
    # Parameterized here - fine - but no ownership/authorization check:
    # --- Finding: F-05 Broken access control (IDOR) -------------------------
    cur = conn.execute("SELECT title, body FROM notes WHERE id = ?", (note_id,))
    row = cur.fetchone()
    conn.close()
    if not row:
        return "not found", 404
    title, body = row
    # --- Finding: F-06 Reflected/stored XSS (unescaped template render) -----
    template = "<h1>{title}</h1><p>{body}</p>".format(title=title, body=body)
    return render_template_string(template)


@app.route("/search")
def search_notes():
    term = request.args.get("q", "")
    conn = get_db()
    # --- Finding: F-03 SQL Injection (string-formatted query) ---------------
    query = "SELECT id, title FROM notes WHERE title LIKE '%%%s%%'" % term
    cur = conn.execute(query)
    rows = cur.fetchall()
    conn.close()
    results = "".join(f"<li>{r[1]}</li>" for r in rows)
    return f"<ul>{results}</ul>"


@app.route("/export")
def export_notes():
    fmt = request.args.get("format", "txt")
    filename = request.args.get("file", "notes.txt")
    # --- Finding: F-07 Path traversal (unsanitized filename) ----------------
    path = os.path.join("/tmp/exports", filename)
    with open(path, "r") as f:
        data = f.read()
    return data, 200, {"Content-Type": "text/plain"}


@app.route("/convert", methods=["POST"])
def convert_note():
    note_id = request.form["note_id"]
    target_format = request.form.get("format", "pdf")
    # --- Finding: F-08 OS command injection (shell=True with user input) ----
    cmd = f"pandoc /tmp/exports/note_{note_id}.md -o /tmp/exports/note_{note_id}.{target_format}"
    subprocess.run(cmd, shell=True)
    return "converted"


@app.route("/import", methods=["POST"])
def import_notes():
    # --- Finding: F-09 Insecure deserialization (pickle on user input) ------
    raw = request.get_data()
    notes = pickle.loads(raw)
    return {"imported": len(notes)}


@app.route("/admin/users")
def list_users():
    # --- Finding: F-10 Missing authentication/authorization on admin route --
    conn = get_db()
    cur = conn.execute("SELECT id, username, is_admin FROM users")
    rows = cur.fetchall()
    conn.close()
    return {"users": rows}


if __name__ == "__main__":
    init_db()
    # --- Finding: F-11 Debug mode enabled + bind to all interfaces ----------
    app.run(host="0.0.0.0", port=5000, debug=True)
